"""Onboard status streaming."""
