"""SkyScan sequential mission orchestration."""
