"""Independent companion safety limits."""
